CREATE TABLE dbo.TestTable (
        Id INT PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL
    );