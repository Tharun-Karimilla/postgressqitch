ALTER TABLE dbo.TestTable
    ADD CreatedDate DATETIME NULL;