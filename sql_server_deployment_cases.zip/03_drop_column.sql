ALTER TABLE dbo.TestTable
    DROP COLUMN Name;