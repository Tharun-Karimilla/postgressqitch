DROP INDEX IX_TestTable_Name ON dbo.TestTable;
    CREATE INDEX IX_TestTable_Name_Alt ON dbo.TestTable (Name DESC);