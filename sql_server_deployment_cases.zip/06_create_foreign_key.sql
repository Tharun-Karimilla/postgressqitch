CREATE TABLE dbo.Parent (
        Id INT PRIMARY KEY
    );
    ALTER TABLE dbo.TestTable
    ADD CONSTRAINT FK_TestTable_Parent FOREIGN KEY (Id) REFERENCES dbo.Parent(Id);