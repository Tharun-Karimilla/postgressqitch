CREATE PROCEDURE dbo.GetTestData
    AS
    BEGIN
        SELECT * FROM dbo.TestTable;
    END