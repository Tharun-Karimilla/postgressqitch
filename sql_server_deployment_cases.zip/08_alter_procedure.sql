ALTER PROCEDURE dbo.GetTestData
    AS
    BEGIN
        SELECT Id, CreatedDate FROM dbo.TestTable;
    END