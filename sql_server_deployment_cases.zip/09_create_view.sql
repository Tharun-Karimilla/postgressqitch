CREATE VIEW dbo.TestView AS
    SELECT Id, Name FROM dbo.TestTable;