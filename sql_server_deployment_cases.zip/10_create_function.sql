CREATE FUNCTION dbo.GetNameLength(@name NVARCHAR(100))
    RETURNS INT
    AS
    BEGIN
        RETURN LEN(@name);
    END