CREATE TRIGGER trg_TestTable_Insert
    ON dbo.TestTable
    AFTER INSERT
    AS
    BEGIN
        PRINT 'Row inserted';
    END