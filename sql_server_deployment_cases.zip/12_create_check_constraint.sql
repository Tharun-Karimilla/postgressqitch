ALTER TABLE dbo.TestTable
    ADD CONSTRAINT CHK_Name_NotEmpty CHECK (LEN(Name) > 0);