EXEC sp_addextendedproperty 
        @name = N'MS_Description', 
        @value = N'Test Table Description', 
        @level0type = N'SCHEMA', @level0name = 'dbo',
        @level1type = N'TABLE',  @level1name = 'TestTable';